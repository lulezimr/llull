import { useEffect, useRef, useState } from "react"

const tracks = [
  {
    id: "L31JqlgTl3w",
    title: "Fading Out Inside",
    type: "Single",
    duration: "3:27",
    image: "/media/music-cover.png",
  },
  {
    id: "PH1_CMg51JU",
    title: "Numb",
    type: "Single",
    duration: "3:23",
    image: "/media/numb.jpg",
  },
  {
    id: "Fr8tx_VWbpk",
    title: "Silence",
    type: "Demo",
    duration: "3:12",
    image: "/media/silence.jpg",
  },
  {
    id: "zZs-NeIxpUA",
    title: "I Remain",
    type: "Demo",
    duration: "3:45",
    image: "/media/i-remain.jpg",
  },
]

const practices = [
  {
    number: "01",
    title: "Visual identities",
    note: "Identity systems, visual languages and communication with a clear point of view.",
  },
  {
    number: "02",
    title: "Digital experiences",
    note: "Interfaces, products and visual systems designed to move naturally on screen.",
  },
  {
    number: "03",
    title: "Editorial & data",
    note: "Publications, information design and complex stories made clear and legible.",
  },
]

function Arrow({ down = false }: { down?: boolean }) {
  return (
    <svg
      className={down ? "arrow arrow--down" : "arrow"}
      viewBox="0 0 24 24"
      aria-hidden="true"
    >
      <path d={down ? "M12 3v17M5 13l7 7 7-7" : "M5 19 19 5M8 5h11v11"} />
    </svg>
  )
}

function WaveField({ active }: { active: boolean }) {
  const canvasRef = useRef<HTMLCanvasElement>(null)
  const pointer = useRef({ x: 0.5, y: 0.5, inside: false })

  useEffect(() => {
    const canvas = canvasRef.current
    if (!canvas) return
    const context = canvas.getContext("2d")
    if (!context) return

    let frame = 0
    let width = 0
    let height = 0
    let reducedMotion = window.matchMedia(
      "(prefers-reduced-motion: reduce)",
    ).matches

    const resize = () => {
      const rect = canvas.getBoundingClientRect()
      const ratio = Math.min(window.devicePixelRatio || 1, 2)
      width = rect.width
      height = rect.height
      canvas.width = Math.round(width * ratio)
      canvas.height = Math.round(height * ratio)
      context.setTransform(ratio, 0, 0, ratio, 0, 0)
    }

    const draw = (time: number) => {
      context.clearRect(0, 0, width, height)
      const lines = width < 700 ? 26 : 42
      const points = 160
      const energy = active ? 1 : 0.35

      for (let line = 0; line < lines; line += 1) {
        const yBase = (height / (lines - 1)) * line
        context.beginPath()
        for (let point = 0; point <= points; point += 1) {
          const x = (width / points) * point
          const centerPull = Math.exp(
            -Math.pow((x - width * 0.52) / (width * 0.29), 2),
          )
          const pointerDistance = pointer.current.inside
            ? Math.exp(
                -Math.pow((x - pointer.current.x * width) / (width * 0.14), 2),
              )
            : 0
          const phase =
            point * 0.24 +
            line * 0.51 +
            (reducedMotion ? 0 : time * 0.0014 * energy)
          const harmonic =
            Math.sin(phase) * 10 +
            Math.sin(phase * 0.47 + line * 0.8) * 18 +
            Math.cos(phase * 1.8) * 3
          const lineCenter = (line - lines / 2) / (lines / 2)
          const envelope = Math.pow(1 - Math.min(Math.abs(lineCenter), 1), 1.8)
          const pointerWave =
            Math.sin(point * 0.42 + time * 0.003) *
            pointerDistance *
            (30 + pointer.current.y * 25)
          const y =
            yBase +
            harmonic * centerPull * envelope * energy +
            pointerWave * envelope
          if (point === 0) context.moveTo(x, y)
          else context.lineTo(x, y)
        }
        const accent =
          line === Math.floor(lines * 0.36) || line === Math.floor(lines * 0.63)
        context.strokeStyle = accent
          ? "rgba(117, 108, 255, .82)"
          : `rgba(236, 235, 227, ${0.11 + line * 0.002})`
        context.lineWidth = accent ? 1.15 : 0.7
        context.stroke()
      }
      frame = requestAnimationFrame(draw)
    }

    const onMove = (event: PointerEvent) => {
      const rect = canvas.getBoundingClientRect()
      pointer.current = {
        x: (event.clientX - rect.left) / rect.width,
        y: (event.clientY - rect.top) / rect.height,
        inside: true,
      }
    }
    const onLeave = () => {
      pointer.current.inside = false
    }
    const media = window.matchMedia("(prefers-reduced-motion: reduce)")
    const onMotionChange = () => {
      reducedMotion = media.matches
    }

    resize()
    window.addEventListener("resize", resize)
    canvas.addEventListener("pointermove", onMove)
    canvas.addEventListener("pointerleave", onLeave)
    media.addEventListener("change", onMotionChange)
    frame = requestAnimationFrame(draw)

    return () => {
      cancelAnimationFrame(frame)
      window.removeEventListener("resize", resize)
      canvas.removeEventListener("pointermove", onMove)
      canvas.removeEventListener("pointerleave", onLeave)
      media.removeEventListener("change", onMotionChange)
    }
  }, [active])

  return <canvas ref={canvasRef} className="wave-field" aria-hidden="true" />
}

function MusicWave({ active }: { active: boolean }) {
  const canvasRef = useRef<HTMLCanvasElement>(null)
  const pointer = useRef({ x: 0.5, y: 0.5, inside: false })

  useEffect(() => {
    const canvas = canvasRef.current
    if (!canvas) return
    const context = canvas.getContext("2d")
    if (!context) return

    let frame = 0
    let width = 0
    let height = 0
    const media = window.matchMedia("(prefers-reduced-motion: reduce)")

    const resize = () => {
      const rect = canvas.getBoundingClientRect()
      const ratio = Math.min(window.devicePixelRatio || 1, 2)
      width = rect.width
      height = rect.height
      canvas.width = Math.round(width * ratio)
      canvas.height = Math.round(height * ratio)
      context.setTransform(ratio, 0, 0, ratio, 0, 0)
    }

    const waveY = (
      x: number,
      time: number,
      layer: number,
      amplitude: number,
    ) => {
      const normalized = x / Math.max(width, 1)
      const cursorPull = pointer.current.inside
        ? Math.exp(-Math.pow((normalized - pointer.current.x) / 0.16, 2)) *
          (pointer.current.y - 0.5) *
          100
        : 0
      const envelope = Math.sin(normalized * Math.PI)
      return (
        height / 2 +
        Math.sin(normalized * 18 + time * (0.0011 + layer * 0.00009) + layer) *
          amplitude *
          envelope +
        Math.cos(normalized * 7 - time * 0.0007 + layer * 1.7) *
          amplitude *
          0.45 +
        cursorPull * envelope
      )
    }

    const draw = (time: number) => {
      context.clearRect(0, 0, width, height)
      const motionTime = media.matches ? 0 : time
      const energy = active ? 1 : 0.42

      context.strokeStyle = "rgba(233, 232, 223, .14)"
      context.lineWidth = 1
      context.beginPath()
      context.moveTo(0, height / 2)
      context.lineTo(width, height / 2)
      context.stroke()

      const bars = width < 700 ? 46 : 92
      for (let index = 0; index < bars; index += 1) {
        const x = (index / (bars - 1)) * width
        const normalized = index / (bars - 1)
        const envelope = Math.pow(Math.sin(normalized * Math.PI), 0.65)
        const pulse =
          0.35 +
          Math.abs(
            Math.sin(index * 0.81 + motionTime * 0.0024) *
              Math.cos(index * 0.17 - motionTime * 0.0013),
          )
        const barHeight = (7 + pulse * 64 * energy) * envelope
        const highlighted = index % 11 === 0 || index % 17 === 0
        context.strokeStyle = highlighted
          ? "rgba(117, 108, 255, .9)"
          : "rgba(233, 232, 223, .32)"
        context.lineWidth = highlighted ? 2 : 1
        context.beginPath()
        context.moveTo(x, height / 2 - barHeight)
        context.lineTo(x, height / 2 + barHeight)
        context.stroke()
      }

      for (let layer = 0; layer < 7; layer += 1) {
        const amplitude = (16 + layer * 7) * energy
        context.beginPath()
        for (let x = -5; x <= width + 5; x += 5) {
          const y = waveY(x, motionTime, layer, amplitude)
          if (x === -5) context.moveTo(x, y)
          else context.lineTo(x, y)
        }
        context.strokeStyle =
          layer === 2
            ? "rgba(117, 108, 255, .95)"
            : layer === 5
              ? "rgba(181, 176, 255, .65)"
              : `rgba(233, 232, 223, ${0.08 + layer * 0.035})`
        context.lineWidth = layer === 2 ? 2.2 : 0.8
        context.stroke()
      }

      for (let particle = 0; particle < 28; particle += 1) {
        const progress =
          (particle / 28 +
            motionTime * (0.000015 + (particle % 4) * 0.000004)) %
          1
        const x = progress * width
        const layer = particle % 7
        const y = waveY(x, motionTime, layer, (16 + layer * 7) * energy)
        context.beginPath()
        context.arc(x, y, particle % 6 === 0 ? 2.4 : 1.1, 0, Math.PI * 2)
        context.fillStyle =
          particle % 6 === 0
            ? "rgba(117, 108, 255, .95)"
            : "rgba(233, 232, 223, .55)"
        context.fill()
      }

      frame = requestAnimationFrame(draw)
    }

    const onMove = (event: PointerEvent) => {
      const rect = canvas.getBoundingClientRect()
      pointer.current = {
        x: (event.clientX - rect.left) / rect.width,
        y: (event.clientY - rect.top) / rect.height,
        inside: true,
      }
    }
    const onLeave = () => {
      pointer.current.inside = false
    }

    resize()
    window.addEventListener("resize", resize)
    canvas.addEventListener("pointermove", onMove)
    canvas.addEventListener("pointerleave", onLeave)
    frame = requestAnimationFrame(draw)

    return () => {
      cancelAnimationFrame(frame)
      window.removeEventListener("resize", resize)
      canvas.removeEventListener("pointermove", onMove)
      canvas.removeEventListener("pointerleave", onLeave)
    }
  }, [active])

  return (
    <div className={`music-wave ${active ? "is-active" : ""}`}>
      <div className="music-wave-meta" aria-hidden="true">
        <span>AMPLITUDE / 02</span>
        <span>{active ? "LIVE FREQUENCY" : "SIGNAL RESTING"}</span>
        <span>44.1 KHZ</span>
      </div>
      <canvas
        ref={canvasRef}
        aria-label="Interactive generative audio visualization"
      />
      <div className="wave-orbit wave-orbit--one" aria-hidden="true" />
      <div className="wave-orbit wave-orbit--two" aria-hidden="true" />
    </div>
  )
}

function App() {
  const [selectedTrack, setSelectedTrack] = useState(0)
  const [playing, setPlaying] = useState(false)
  const [menuOpen, setMenuOpen] = useState(false)
  const track = tracks[selectedTrack]

  useEffect(() => {
    const items = document.querySelectorAll<HTMLElement>("[data-reveal]")
    const observer = new IntersectionObserver(
      (entries) =>
        entries.forEach(
          (entry) =>
            entry.isIntersecting && entry.target.classList.add("is-visible"),
        ),
      { threshold: 0.12 },
    )
    items.forEach((item) => observer.observe(item))
    return () => observer.disconnect()
  }, [])

  const selectTrack = (index: number) => {
    setSelectedTrack(index)
    setPlaying(true)
  }

  return (
    <main id="top">
      <header className="site-header">
        <a className="logo" href="#top" aria-label="llull, home">
          llull<sup>®</sup>
        </a>
        <p className="header-practice">
          Independent creative practice
          <br />
          Prishtina, Kosovo
        </p>
        <button
          className="menu-toggle"
          type="button"
          aria-expanded={menuOpen}
          aria-controls="main-nav"
          onClick={() => setMenuOpen((value) => !value)}
        >
          {menuOpen ? "Close" : "Menu"}
        </button>
        <nav
          id="main-nav"
          className={menuOpen ? "is-open" : ""}
          aria-label="Primary navigation"
        >
          {[
            ["Work", "work"],
            ["Sound", "sound"],
            ["About", "about"],
            ["Contact", "contact"],
          ].map(([label, id], index) => (
            <a key={id} href={`#${id}`} onClick={() => setMenuOpen(false)}>
              <small>0{index + 1}</small>
              {label}
            </a>
          ))}
        </nav>
      </header>

      <section className="hero" aria-labelledby="hero-title">
        <WaveField active={playing} />
        <div className="hero-grid" aria-hidden="true" />
        <div className="hero-meta">
          <span>DESIGNER / VISUAL ARTIST / MUSICIAN</span>
          <span>45.2671° N / 19.8335° E</span>
          <span>SIGNAL {playing ? "LIVE" : "IDLE"}</span>
        </div>
        <h1 id="hero-title" className="hero-statement">
          Ideas with <em>rhythm</em>
          <br />
          and resonance.
        </h1>
        <a
          className="signal-control"
          href="https://www.youtube.com/@llull.r"
          target="_blank"
          rel="noreferrer"
          aria-label="Visit the LLULLI YouTube channel"
        >
          <span className="play-glyph" aria-hidden="true" />
          <span>Play signal</span>
          <small>LLULLI channel / YouTube</small>
        </a>
        <div className="hero-foot">
          <p>
            Visual identities, digital experiences and sound,
            <br />
            built to leave a clear trace.
          </p>
          <a href="#work">
            Explore the practice <Arrow down />
          </a>
        </div>
        <p className="simulation-note">
          GENERATIVE VISUAL FIELD / REAL AUDIO VIA YOUTUBE
        </p>
      </section>

      <section className="work paper-section" id="work">
        <div className="section-label" data-reveal>
          <p>Selected visual work / 01</p>
          <p>
            Strategy, form and systems
            <br />
            across screen and print.
          </p>
        </div>
        <div className="work-heading" data-reveal>
          <h2>
            One practice.
            <br />
            <em>Multiple frequencies.</em>
          </h2>
          <span className="edition">LR—10+</span>
        </div>
        <div className="practice-list">
          {practices.map((practice) => (
            <article className="practice-row" key={practice.number} data-reveal>
              <span>{practice.number}</span>
              <h3>{practice.title}</h3>
              <p>{practice.note}</p>
              <Arrow />
            </article>
          ))}
        </div>
        <a
          className="behance-strip"
          href="https://www.behance.net/ramusa"
          target="_blank"
          rel="noreferrer"
        >
          <span>View selected visual projects</span>
          <strong>BEHANCE / RAMUSA</strong>
          <Arrow />
        </a>
      </section>

      <section className="sound" id="sound">
        <div className="section-label section-label--dark" data-reveal>
          <p>Independent music / 02</p>
          <p>
            Written and recorded
            <br />
            under the name LLULLI.
          </p>
        </div>
        <div className="sound-title" data-reveal>
          <h2>
            Turn the noise
            <br />
            into <em>meaning.</em>
          </h2>
          <p>Voice, guitar, tension, release.</p>
        </div>
        <MusicWave active={playing} />
        <div className="music-layout" data-reveal>
          <div className="artwork">
            <img src={track.image} alt={`Artwork for ${track.title}`} />
            <div className="artwork-stamp">
              LLULLI
              <br />
              SIDE—A
            </div>
            <button type="button" onClick={() => setPlaying((value) => !value)}>
              <span
                className={playing ? "pause-glyph" : "play-glyph"}
                aria-hidden="true"
              />
              <span>{playing ? "Stop" : "Listen"}</span>
            </button>
          </div>
          <div className="track-panel">
            <div className="track-panel-head">
              <span>Index / audio works</span>
              <span>04 tracks</span>
            </div>
            {tracks.map((item, index) => (
              <button
                type="button"
                className={
                  selectedTrack === index ? "track is-selected" : "track"
                }
                key={item.id}
                onClick={() => selectTrack(index)}
              >
                <span>{String(index + 1).padStart(2, "0")}</span>
                <strong>{item.title}</strong>
                <small>{item.type}</small>
                <time>{item.duration}</time>
                <i aria-hidden="true" />
              </button>
            ))}
            <a
              className="channel-link"
              href="https://www.youtube.com/@llull.r"
              target="_blank"
              rel="noreferrer"
            >
              Visit the LLULLI channel <Arrow />
            </a>
          </div>
        </div>
      </section>

      <section className="about paper-section" id="about">
        <div className="section-label" data-reveal>
          <p>About / 03</p>
          <p>
            One person.
            <br />
            Several ways of thinking.
          </p>
        </div>
        <h2 data-reveal>
          Form follows
          <br />
          <em>curiosity.</em>
        </h2>
        <div className="about-layout">
          <figure className="portrait" data-reveal>
            <div className="portrait-frame">
              <img src="/media/portrait.jpg" alt="Portrait of Lulezim Ramusa" />
              <span>03 — PROFILE</span>
            </div>
            <figcaption>
              <span>Lulezim Ramusa</span>
              <span>Prishtina, Kosovo</span>
            </figcaption>
          </figure>
          <div className="experience" data-reveal>
            <strong>10+</strong>
            <span>
              Years of
              <br />
              practice
            </span>
          </div>
          <div className="bio" data-reveal>
            <p>
              Lulezim Ramusa is a Senior Graphic Designer and Visual Designer
              with over 10 years of professional experience. His work combines
              strong visual thinking, conceptual development, and a practical
              understanding of digital and print media.
            </p>
            <p>
              He has worked across international and local markets, including
              Switzerland, developing visual identities, communication
              materials, digital experiences, editorial design and data
              visualization.
            </p>
            <p>
              He holds a Master’s degree in Graphic Design and Multimedia from
              the University of Prishtina and pursued graduate studies in Art at
              Hacettepe University in Ankara. As Llull, he also works as a
              vocalist, lead guitarist, composer and songwriter.
            </p>
            <p>
              Across disciplines, his practice is driven by an interest in
              visual storytelling, experimentation and authentic creative
              expression.
            </p>
          </div>
        </div>
      </section>

      <footer id="contact">
        <div className="section-label section-label--dark" data-reveal>
          <p>Contact / 04</p>
          <p>
            Have a project, collaboration
            <br />
            or unusual idea in mind?
          </p>
        </div>
        <h2 data-reveal>
          Let’s make
          <br />
          <em>something</em> resonate.
        </h2>
        <div className="footer-links" data-reveal>
          <a
            href="https://www.behance.net/ramusa"
            target="_blank"
            rel="noreferrer"
          >
            Behance <Arrow />
          </a>
          <a
            href="https://www.youtube.com/@llull.r"
            target="_blank"
            rel="noreferrer"
          >
            YouTube <Arrow />
          </a>
        </div>
        <address data-reveal>
          <a href="mailto:lulezimramusa@gmail.com">
            <small>Email</small>
            <span>lulezimramusa@gmail.com</span>
          </a>
          <a href="tel:+38345312783">
            <small>Phone</small>
            <span>+383 45 312 783</span>
          </a>
          <a
            href="https://www.google.com/maps/search/?api=1&query=St.+Bajram+Kelmendi+Nr.+48+F4+Prishtine"
            target="_blank"
            rel="noreferrer"
          >
            <small>Address</small>
            <span>
              St. Bajram Kelmendi, Nr. 48 F4
              <br />
              Prishtine
            </span>
          </a>
        </address>
        <div className="footer-row">
          <span>© {new Date().getFullYear()} Lulezim Ramusa</span>
          <span>Design / Art / Music</span>
          <a href="#top">Back to top ↑</a>
        </div>
      </footer>

      {playing && (
        <aside className="sound-dock" aria-label={`Now playing ${track.title}`}>
          <div className="sound-dock-head">
            <span>NOW PLAYING / {track.title}</span>
            <button
              type="button"
              onClick={() => setPlaying(false)}
              aria-label="Stop playback"
            >
              STOP ×
            </button>
          </div>
          <iframe
            src={`https://www.youtube.com/embed/${track.id}?autoplay=1&rel=0`}
            title={`${track.title} by LLULLI`}
            allow="autoplay; encrypted-media; picture-in-picture"
            allowFullScreen
          />
        </aside>
      )}
    </main>
  )
}

export default App
